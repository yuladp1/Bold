new Vue({
    el: "#app",
    data: {
      menuOpen: false,
    },
    methods: {
      toggleMenu() {
        return this.menuOpen = !this.menuOpen; 
      },
    },
  })
